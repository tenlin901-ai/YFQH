import requests
import random
import time
from proxy_config import SMARTPROXY

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/121.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Safari/605.1.15",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0) AppleWebKit/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0",
]

def get_session():
    session = requests.Session()
    session.headers.update({
        "User-Agent": random.choice(USER_AGENTS),
        "Accept-Language": "en-US,en;q=0.9",
    })
    session.proxies.update(SMARTPROXY)
    return session

def safe_get(session, url):
    time.sleep(random.uniform(4.5, 8.5))
    try:
        resp = session.get(url, timeout=20)
        return resp
    except Exception as e:
        print("❌ request error:", e)
        return None
