import requests

API_KEY = "72fef0095c4cfd74577d224365f1cf1e"

def fetch_match_xg(match_id):
    url = f"https://v3.football.api-sports.io/fixtures?id={match_id}"
    headers = { "x-apisports-key": API_KEY }
    r = requests.get(url, headers=headers)
    return r.json()
