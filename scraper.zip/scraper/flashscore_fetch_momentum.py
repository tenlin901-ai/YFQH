from proxy_session import get_session, safe_get
import json

def fetch_momentum(match_id):
    url = f"https://d.flashscore.com/x/feed/momentum/{match_id}"
    session = get_session()

    r = safe_get(session, url)
    try:
        return json.loads(r.text)
    except:
        return None
