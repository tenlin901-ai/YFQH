from proxy_session import get_session, safe_get
import json
import re

URL = "https://www.flashscore.com/x/feed/d_today_0_en_1/"

def fetch_today_matches():
    session = get_session()

    r = safe_get(session, URL)
    if not r:
        print("❌ Failed to fetch match list (network)")
        return []

    text = r.text

    # FlashScore 返回的是 JS 包装，需要正则抽 JSON
    json_text = re.findall(r'\{.*\}', text)
    if not json_text:
        print("❌ Failed to parse match list")
        return []

    data = json.loads(json_text[0])

    events = data.get("events", [])
    matches = [e.get("id") for e in events if e.get("id")]

    print(f"✔ 今日比赛数量: {len(matches)}")
    return matches
