import requests
import os

proxy = {
    "http": f"http://{os.getenv('SP_USER')}:{os.getenv('SP_PASS')}@proxy.smartproxycn.com:10000",
    "https": f"http://{os.getenv('SP_USER')}:{os.getenv('SP_PASS')}@proxy.smartproxycn.com:10000"
}

print("正在请求 ipinfo.io ...")

try:
    r = requests.get("https://ipinfo.io/json", proxies=proxy, timeout=10)
    print("代理返回:", r.text)
except Exception as e:
    print("代理请求失败:", e)
