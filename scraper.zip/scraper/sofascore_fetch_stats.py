from proxy_session import get_session, safe_get
import json

def fetch_sofascore_stats(match_id):
    # SofaScore fixture API
    url = f"https://www.sofascore.com/api/v1/event/{match_id}/statistics"
    session = get_session()

    r = safe_get(session, url)
    try:
        return json.loads(r.text)
    except:
        return None
