from proxy_session import get_session, safe_get
from bs4 import BeautifulSoup

def fetch_ah(match_id):
    url = f"https://www.flashscore.com/match/{match_id}/#odds-comparison;ah"
    session = get_session()

    resp = safe_get(session, url)
    if not resp:
        return None

    soup = BeautifulSoup(resp.text, "html.parser")

    table = soup.find("div", {"id": "odds_ah"})
    if not table:
        return None

    odds = {}
    rows = table.find_all("div", {"class": "ui-table__row"})
    for row in rows:
        spans = row.find_all("span")
        if len(spans) < 4:
            continue

        bookmaker = spans[0].text.strip()
        line = spans[1].text.strip()
        home_odds = spans[2].text.strip()
        away_odds = spans[3].text.strip()

        odds[bookmaker] = {
            "line": line,
            "home": home_odds,
            "away": away_odds
        }

    return odds
