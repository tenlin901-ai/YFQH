from flashscore_fetch_matchlist import fetch_today_matches
from flashscore_fetch_ah import fetch_ah
from flashscore_fetch_momentum import fetch_momentum
from sofascore_fetch_stats import fetch_sofascore_stats
import json
import os
import time

os.makedirs("data/raw", exist_ok=True)

def run():
    matches = fetch_today_matches()

    for mid in matches:
        print(f"\n===== 抓取 {mid} =====")

        ah = fetch_ah(mid)
        momentum = fetch_momentum(mid)
        stats = fetch_sofascore_stats(mid)

        data = {
            "match_id": mid,
            "ah": ah,
            "momentum": momentum,
            "stats": stats
        }

        with open(f"data/raw/{mid}.json", "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

        time.sleep(3.0)

    print("\n✔ 今日全部比赛抓取完成")

if __name__ == "__main__":
    run()
