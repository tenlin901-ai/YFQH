import os

# 你的 SmartProxy endpoint
PROXY_HOST = "eu.smartproxycn.com"
PROXY_PORT = 1000

SMARTPROXY = {
    "http":  f"http://{os.getenv('SP_USER')}:{os.getenv('SP_PASS')}@{PROXY_HOST}:{PROXY_PORT}",
    "https": f"http://{os.getenv('SP_USER')}:{os.getenv('SP_PASS')}@{PROXY_HOST}:{PROXY_PORT}",
}
