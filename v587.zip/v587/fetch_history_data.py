# -*- coding: utf-8 -*-
import os, csv, requests

BASE_URL = "https://www.football-data.co.uk/mmz4281"

# 自动抓取 23/24 回溯到 93/94（完整历史）
def gen_seasons(start="2324", end="9394"):
    ys = []
    s1, s2 = int(start[:2]), int(start[2:])
    e1, e2 = int(end[:2]), int(end[2:])
    cur1, cur2 = s1, s2
    while True:
        ys.append(f"{cur1:02d}{cur2:02d}")
        if cur1 == e1 and cur2 == e2:
            break
        cur2 -= 1
        cur1 -= 1
        if cur2 < 0:
            cur2 = 99
        if cur1 < 0:
            break
    return ys

SEASONS = gen_seasons("2324", "9394")

LEAGUES = {
    "E0": "E0",
    "SP1": "SP1",
    "I1": "I1",
    "D1": "D1",
    "F1": "F1",
    "B1": "B1",
    "P1": "P1",
    "N1": "N1",
    "T1": "T1",
    "DNK1": "DNK1",
    "SWE1": "SWE1",
    "BRA1": "BRA1",
    "ARG1": "ARG1",
    "EC": "EC",
    "EL": "EL",
}

DATA_DIR = "data"
os.makedirs(DATA_DIR, exist_ok=True)

def fetch_league_history(code: str):
    rows = []
    header = None
    for s in SEASONS:
        url = f"{BASE_URL}/{s}/{LEAGUES[code]}.csv"
        try:
            r = requests.get(url, timeout=20)
            if r.status_code != 200 or len(r.content) < 500:
                continue
            text = r.content.decode("latin1")
            for i, row in enumerate(csv.reader(text.splitlines())):
                if i == 0:
                    header = row
                    continue
                if not row:
                    continue
                rows.append(row)
        except:
            continue

    if not rows or header is None:
        return

    out_path = os.path.join(DATA_DIR, f"history_{code}.csv")
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)

if __name__ == "__main__":
    for lg in LEAGUES.keys():
        fetch_league_history(lg)
