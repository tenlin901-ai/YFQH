# -*- coding: utf-8 -*-
import os, joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

DATA_DIR = "data"
MODEL_DIR = "models"
os.makedirs(MODEL_DIR, exist_ok=True)

LEAGUES = ["E0","SP1","I1","D1","F1","B1","P1","N1","T1","DNK1","SWE1","BRA1","ARG1","EC","EL"]

def build_ah_dataset(df):
    df = df.copy()
    df.columns = [c.lower().strip() for c in df.columns]
    df = df.rename(columns={"hometeam":"home_team","awayteam":"away_team","ftr":"result"})

    if "bbahh" in df.columns:
        df["ah_line"] = df["bbahh"].astype(float)
    else:
        return None

    if "bbmxh" in df.columns and "bbmxa" in df.columns:
        df["ah_home_odds"] = df["bbmxh"].astype(float)
        df["ah_away_odds"] = df["bbmxa"].astype(float)
    else:
        return None

    df["fav_is_home"] = (df["ah_home_odds"] < df["ah_away_odds"]).astype(int)
    qh = 1 / df["ah_home_odds"]
    qa = 1 / df["ah_away_odds"]
    s = qh + qa
    df["prob_spread_home_away"] = qh/s - qa/s

    df["y"] = df["result"].astype(str).str.upper().str[0:1].map({"H":1,"A":0})
    df = df.dropna(subset=["ah_line","ah_home_odds","ah_away_odds","prob_spread_home_away","y"])

    X = df[["ah_line","ah_home_odds","ah_away_odds","fav_is_home","prob_spread_home_away"]].values
    y = df["y"].astype(int).values
    return X, y

def train_league(code):
    path = os.path.join(DATA_DIR, f"history_{code}.csv")
    if not os.path.exists(path):
        return

    df = pd.read_csv(path, on_bad_lines="skip", low_memory=False)
    out = build_ah_dataset(df)
    if out is None:
        return

    X, y = out
    if len(X) < 500:
        return

    pipe = Pipeline([
        ("scaler", StandardScaler()),
        ("gbm", GradientBoostingClassifier(
            n_estimators=300,
            learning_rate=0.05,
            max_depth=3,
            subsample=0.8,
        ))
    ])

    pipe.fit(X, y)
    joblib.dump(
        {"pipeline": pipe, "feature_cols": ["ah_line","ah_home_odds","ah_away_odds","fav_is_home","prob_spread_home_away"]},
        f"models/ah_model_{code}.pkl"
    )

if __name__ == "__main__":
    for lg in LEAGUES:
        train_league(lg)
