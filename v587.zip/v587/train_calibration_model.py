# -*- coding: utf-8 -*-
"""
train_calibration_model.py
训练 v5 的概率校准模型，用 strategy_dataset.csv 中的 p_model 与真实结果做校准
"""

import pandas as pd
import joblib
from sklearn.calibration import CalibratedClassifierCV
from sklearn.linear_model import LogisticRegression

DATA_PATH = "data/strategy_dataset.csv"
MODEL_PATH = "models/calibration_model.pkl"


def main():

    df = pd.read_csv(DATA_PATH)
    df = df.dropna(subset=["p_model", "y"])

    X = df[["p_model"]].values
    y = df["y"].astype(int).values

    # 基模型用 LogReg（Platt scaling）
    base = LogisticRegression()
    cal = CalibratedClassifierCV(base, cv=3, method="sigmoid")

    cal.fit(X, y)

    joblib.dump({"calibrator": cal}, MODEL_PATH)

    print("Saved:", MODEL_PATH)


if __name__ == "__main__":
    main()
