# -*- coding: utf-8 -*-
"""
odds_loader.py
负责批量拉取盘口，提升 main 的整洁性。
"""

import httpx


# sport_key → league_code
league_map = {
    "soccer_epl": "E0",
    "soccer_spain_la_liga": "SP1",
    "soccer_italy_serie_a": "I1",
    "soccer_germany_bundesliga": "D1",
    "soccer_france_ligue_one": "F1",
    "soccer_belgium_first_div": "B1",
    "soccer_portugal_primeira_liga": "P1",
    "soccer_netherlands_eredivisie": "N1",
    "soccer_turkey_super_league": "T1",
    "soccer_denmark_superliga": "DNK1",
    "soccer_sweden_allsvenskan": "SWE1",
    "soccer_brazil_campeonato": "BRA1",
    "soccer_argentina_primera_division": "ARG1",
    "soccer_uefa_champs_league": "EC",
    "soccer_uefa_europa_league": "EL",
}


def fetch_all_odds(sports_list, api_key, region):
    """批量拉取多个联赛赔率"""

    all_data = {}

    for sport in sports_list:
        try:
            url = f"https://api.the-odds-api.com/v4/sports/{sport}/odds"
            params = {
                "apiKey": api_key,
                "regions": region,
                "markets": "h2h,spreads",
                "oddsFormat": "decimal",
            }

            r = httpx.get(url, params=params, timeout=25)
            if r.status_code == 200:
                all_data[sport] = r.json()
            else:
                all_data[sport] = []

        except:
            all_data[sport] = []

    return all_data
