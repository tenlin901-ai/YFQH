# -*- coding: utf-8 -*-
"""
logger.py
写入 CSV 日志
"""

import os
import csv
from datetime import datetime


def log_signal(sig, path):
    new = not os.path.exists(path)

    with open(path, "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=sig.keys())
        if new:
            w.writeheader()
        w.writerow(sig)
