# -*- coding: utf-8 -*-
"""
predictor.py
统一处理一场比赛的预测流程：盘口聚合、特征生成、模型预测、EV计算。
"""

import numpy as np
from v5.utils.calibration import apply_calibration
from v5.features.agg_depth import depth_stats
from v5.features.xg_features import rolling_xg_features
from v5.features.player_status import analyze_player_status
from v5.features.form_metrics import form_metrics
from v5.features.weather import weather_features


# ========== 去水 ==========
def remove_vig(home, draw, away):
    try:
        inv = [1/home, 1/draw, 1/away]
        s = sum(inv)
        return inv[0]/s, inv[1]/s, inv[2]/s
    except:
        return None, None, None


# ========== 特征构建（精简版） ==========
def build_features(game, league, matchup, kickoff_dt, h2h_pi, line, odds_home, odds_away, data):

    home, away = matchup
    MATCH, PLAYER, XG, WEATHER = data

    # xG
    xg_h = rolling_xg_features(XG, home, kickoff_dt)
    xg_a = rolling_xg_features(XG, away, kickoff_dt)

    # 阵容
    ps_h = analyze_player_status(PLAYER, home, kickoff_dt)
    ps_a = analyze_player_status(PLAYER, away, kickoff_dt)

    # form
    fm_h = form_metrics(MATCH, home, kickoff_dt)
    fm_a = form_metrics(MATCH, away, kickoff_dt)

    # weather
    w = weather_features(WEATHER)

    feats = {
        "line": line,
        "odds_home": odds_home,
        "odds_away": odds_away,
        "prob_home_h2h": h2h_pi[0],
        "prob_away_h2h": h2h_pi[2],
    }

    # 合并全部特征
    for k, v in xg_h.items(): feats[f"home_{k}"] = v
    for k, v in xg_a.items(): feats[f"away_{k}"] = v

    for k, v in ps_h.items(): feats[f"home_{k}"] = v
    for k, v in ps_a.items(): feats[f"away_{k}"] = v

    for k, v in fm_h.items(): feats[f"home_{k}"] = v
    for k, v in fm_a.items(): feats[f"away_{k}"] = v

    for k, v in w.items(): feats[k] = v

    return feats


# ========== 盘口聚合 ==========

def aggregate_h2h(game, home, away):
    prices_h, prices_d, prices_a = [], [], []

    for b in game.get("bookmakers", []):
        for m in b.get("markets", []):
            if m.get("key") != "h2h":
                continue
            for o in m.get("outcomes", []):
                name = o.get("name","").lower()
                price = o.get("price", None)
                if price is None:
                    continue
                price = float(price)
                if "draw" in name:
                    prices_d.append(price)
                elif home.lower() in name:
                    prices_h.append(price)
                elif away.lower() in name:
                    prices_a.append(price)

    if not prices_h or not prices_d or not prices_a:
        return None

    home_med = np.median(prices_h)
    draw_med = np.median(prices_d)
    away_med = np.median(prices_a)

    return home_med, draw_med, away_med


def aggregate_spreads(game, home, away):
    out = {}
    for b in game.get("bookmakers", []):
        for m in b.get("markets", []):
            if m.get("key") != "spreads":
                continue
            for o in m.get("outcomes", []):
                name = o.get("name","").lower()
                price = o.get("price")
                point = o.get("point")
                if price is None or point is None:
                    continue
                if home.lower() in name:
                    out.setdefault(point, {})["home"] = float(price)
                if away.lower() in name:
                    out.setdefault(point, {})["away"] = float(price)
    # 只保留成对盘口
    final = {}
    for L, d in out.items():
        if "home" in d and "away" in d:
            final[L] = {"home": d["home"], "away": d["away"]}
    return final


# ========== 主预测管线 ==========
def run_pipeline(game, league, models, ev_threshold, tz):
    """
    对单场比赛生成 signals（未经过 kelly / 风控）
    """

    home = game["home_team"]
    away = game["away_team"]

    # 判断是否在扫描窗口
    dt = game.get("commence_time")
    if dt is None:
        return []

    # H2H
    h2h = aggregate_h2h(game, home, away)
    if not h2h:
        return []

    pi = remove_vig(*h2h)

    # AH spreads
    spreads = aggregate_spreads(game, home, away)
    if not spreads:
        return []

    # 数据打包
    MATCH_DATA, PLAYER_DATA, XG_DATA, WEATHER_DATA = (
        models.get("MATCH_DATA"),
        models.get("PLAYER_DATA"),
        models.get("XG_DATA"),
        models.get("WEATHER_DATA"),
    )
    data = (MATCH_DATA, PLAYER_DATA, XG_DATA, WEATHER_DATA)

    signals = []

    # 多盘口处理
    for line, od in spreads.items():
        odd_h = od["home"]
        odd_a = od["away"]

        feats = build_features(
            game, league, (home, away), game["kickoff_dt"],
            pi, line, odd_h, odd_a, data
        )

        # 主模型预测 AH
        ah_bundle = models.get("ah_models", {}).get(league)
        if ah_bundle is None:
            continue

        X = np.array([[feats.get(c, 0) for c in ah_bundle["feature_cols"]]], float)
        p_raw = ah_bundle["pipeline"].predict_proba(X)[0, 1]

        # 校准
        p_cal = apply_calibration(p_raw)

        # EV
        ev = p_cal * odd_h - 1

        if ev >= ev_threshold:
            signals.append({
                "league": league,
                "home": home,
                "away": away,
                "side": "home",
                "line": line,
                "odds": odd_h,
                "p_cal": p_cal,
                "ev": ev,
                "move_prob": 0.5,
            })

    return signals
