# -*- coding: utf-8 -*-
"""
signal_builder.py
负责 Kelly 后的信号过滤（风控）。
"""


def build_final_signals(signals, risk_engine):
    """风控过滤（逐条判定）"""
    final = []
    for s in signals:
        if risk_engine.approve(
            s["stake"], s["ev"], s["p_cal"], s["p_cal"]
        ):
            final.append(s)
    return final
