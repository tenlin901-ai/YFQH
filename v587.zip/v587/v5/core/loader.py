# -*- coding: utf-8 -*-
"""
loader.py
负责加载所有模型：AH、策略层、校准、line-move、meta。
"""

import os
import joblib


def load_single(path):
    """安全加载单个模型"""
    if os.path.exists(path):
        try:
            return joblib.load(path)
        except:
            return None
    return None


def load_all_models():
    """一次性加载全部模型，main 直接用"""

    model_paths = {
        "strategy": "models/strategy_model_v2.pkl",
        "calibration": "models/calibration_model.pkl",
        "line_move": "models/line_move_model.pkl",
        "meta": "models/meta_model.pkl",
    }

    models = {}

    for key, path in model_paths.items():
        models[key] = load_single(path)

    return models
