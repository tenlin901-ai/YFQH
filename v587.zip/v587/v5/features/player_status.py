# -*- coding: utf-8 -*-
"""
Player Status Features（球员状态 / 伤停 / 出场 / rating 特征）
-----------------------------------------------------------------
用于描述球队阵容完整度，包括：
- 主力缺阵数量
- 红黄牌停赛
- 最近 5 场出场时间（体能过载）
- 球员 rating 趋势（form）
- 关键位置缺阵惩罚
- Lineup Integrity Score（阵容完整度评分）
- Injury Impact Index（伤停影响指数）
"""

import numpy as np
import pandas as pd

# 关键位置权重（可调）
POSITION_WEIGHT = {
    "GK": 1.0,
    "CB": 0.9,
    "LB": 0.6,
    "RB": 0.6,
    "DM": 0.8,
    "CM": 0.7,
    "AM": 0.7,
    "LW": 0.6,
    "RW": 0.6,
    "ST": 0.9,
}

def analyze_player_status(df_players, team, dt):
    """
    df_players 格式要求：
    ---------------------------------
    date
    team
    player_name
    position
    minutes
    rating
    injured (0/1)
    suspended (0/1)
    starter (0/1)
    ---------------------------------

    输入：
    - 一个包含球员状态信息的 DataFrame
    - 比赛队伍名称
    - 截止日期（比赛时间）

    输出：
    - 多项球员状态特征，用于策略层 + 主模型
    """

    sub = df_players[
        (df_players["team"] == team) &
        (df_players["date"] < dt)
    ].sort_values("date")

    if len(sub) == 0:
        return {
            "injured_count": np.nan,
            "suspended_count": np.nan,
            "starters_missing": np.nan,
            "avg_minutes_last5": np.nan,
            "avg_rating_last5": np.nan,
            "rating_momentum": np.nan,
            "lineup_integrity": np.nan,
            "injury_impact_index": np.nan,
        }

    # 最近一次比赛的阵容（用于判断主力缺阵）
    last_match = sub.groupby("player_name").tail(1)

    injured_count = last_match["injured"].sum()
    suspended_count = last_match["suspended"].sum()

    # 主力定义：starter=1 并且最近三场式连续上场
    starters = last_match[last_match["starter"] == 1]
    starters_missing = starters["injured"].sum() + starters["suspended"].sum()

    # 最近 5 场的出场时间 + rating
    last5 = sub.tail(5)
    avg_minutes_last5 = last5["minutes"].mean() if len(last5) > 0 else np.nan
    avg_rating_last5 = last5["rating"].mean() if len(last5) > 0 else np.nan

    # rating 动能（斜率）
    if len(last5) >= 3:
        rating_vals = last5["rating"].values
        rating_momentum = np.polyfit(range(len(rating_vals)), rating_vals, 1)[0]
    else:
        rating_momentum = np.nan

    # 关键位置缺人惩罚
    key_penalty = 0.0
    for _, row in last_match.iterrows():
        if row["injured"] == 1 or row["suspended"] == 1:
            pos = row.get("position", None)
            if pos in POSITION_WEIGHT:
                key_penalty += POSITION_WEIGHT[pos]

    # 阵容完整度评分（1 = 完整，0 = 损失严重）
    lineup_integrity = max(0.0, 1.0 - key_penalty / 6.0)

    # 综合伤停影响指数（0~1）
    injury_impact_index = min(
        1.0,
        (injured_count * 0.4) +
        (suspended_count * 0.3) +
        (starters_missing * 0.5) +
        (key_penalty * 0.8)
    )

    return {
        "injured_count": float(injured_count),
        "suspended_count": float(suspended_count),
        "starters_missing": float(starters_missing),
        "avg_minutes_last5": float(avg_minutes_last5),
        "avg_rating_last5": float(avg_rating_last5),
        "rating_momentum": float(rating_momentum),
        "lineup_integrity": float(lineup_integrity),
        "injury_impact_index": float(injury_impact_index),
    }
