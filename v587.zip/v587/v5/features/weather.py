# -*- coding: utf-8 -*-
"""
Weather Impact Features (WII - Weather Impact Index)
------------------------------------------------------
天气对比赛的影响十分显著：
- 低温：进攻效率下降
- 高温：体能下降、后半场失误增多
- 大风：长传成功率降低
- 降雨：防守端滑倒率上升、意外失误增多

本模块将原始天气数据转换成可用于模型的特征。
"""

import numpy as np
import pandas as pd

def weather_basic(temp_c, humidity, wind_kph, rain_mm):
    """
    输入为每场比赛或城市的天气情况：
    - temp_c: 温度（摄氏度）
    - humidity: 湿度（%）
    - wind_kph: 风速（km/h）
    - rain_mm: 降雨量（毫米）

    输出基础特征：
    - temperature_index（舒适度指数）
    - wind_index（风影响）
    - rain_index（雨影响）
    - humidity_index
    """

    # 温度影响：15~22 最佳，大于 30 极度影响
    if temp_c is None:
        temperature_index = np.nan
    else:
        temperature_index = -abs(temp_c - 20) / 20.0

    # 湿度影响（高湿闷热、小雨中等、干燥好）
    humidity_index = -(humidity - 50)**2 / 2500 if humidity is not None else np.nan

    # 风速影响
    wind_index = min(1.0, wind_kph / 40.0) if wind_kph is not None else np.nan

    # 雨量影响
    if rain_mm is None:
        rain_index = np.nan
    else:
        if rain_mm == 0:
            rain_index = 0.0
        elif rain_mm < 2:
            rain_index = 0.1
        elif rain_mm < 5:
            rain_index = 0.25
        elif rain_mm < 10:
            rain_index = 0.4
        else:
            rain_index = 0.6  # 大雨显著影响控球

    return {
        "temperature_index": float(temperature_index),
        "humidity_index": float(humidity_index),
        "wind_index": float(wind_index),
        "rain_index": float(rain_index),
    }

def compute_WII(temp_c, humidity, wind_kph, rain_mm):
    """
    Weather Impact Index
    ---------------------
    一个综合评分，衡量天气对比赛的整体干扰程度。
    WII 接近 0 → 理想天气
    WII 接近 1 → 极度恶劣
    """

    base = weather_basic(temp_c, humidity, wind_kph, rain_mm)

    # 综合影响（归一化）
    w = (
        abs(base["temperature_index"]) * 0.3 +
        base["wind_index"] * 0.25 +
        base["rain_index"] * 0.25 +
        abs(base["humidity_index"]) * 0.20
    )

    return {
        "WII": float(w),
        **base
    }

def weather_features(row):
    """
    对比赛行数据进行天气特征转化。
    row 包含字段：
        temp_c / humidity / wind_kph / rain_mm
    """
    return compute_WII(
        row.get("temp_c"),
        row.get("humidity"),
        row.get("wind_kph"),
        row.get("rain_mm"),
    )
