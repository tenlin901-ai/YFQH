# -*- coding: utf-8 -*-
"""
xG 特征生成模块（Expected Goals Features）
----------------------------------------------
提供如下特征：
- rolling xG / xGA（10/20/30 场窗口）
- attack_strength（进攻强度）
- defense_stability（防守稳定度）
- xG momentum（进攻“动能”）
- xGA collapse index（防线崩溃指数）
"""

import pandas as pd
import numpy as np

def _safe_mean(x):
    x = [v for v in x if pd.notna(v)]
    return np.mean(x) if x else np.nan

def rolling_xg_features(df, team, dt):
    """
    df 格式要求：
    columns:
        date (datetime)
        team
        opponent
        xg
        xga
        gf  (进球)
        ga  (失球)
    """
    sub = df[
        (df["team"] == team) &
        (df["date"] < dt)
    ].sort_values("date")

    if len(sub) == 0:
        return {k: np.nan for k in [
            "xg_10", "xga_10", "xg_20", "xga_20", "xg_30", "xga_30",
            "attack_strength", "defense_stability",
            "xg_momentum", "xga_collapse"
        ]}

    def roll(col, N):
        return _safe_mean(sub[col].tail(N).values)

    # rolling windows
    xg_10  = roll("xg", 10)
    xga_10 = roll("xga", 10)
    xg_20  = roll("xg", 20)
    xga_20 = roll("xga", 20)
    xg_30  = roll("xg", 30)
    xga_30 = roll("xga", 30)

    # 攻防强度指标
    attack_strength = (
        (xg_10 or 0) * 0.5 +
        (xg_20 or 0) * 0.3 +
        (xg_30 or 0) * 0.2
    )

    defense_stability = (
        -(xga_10 or 0) * 0.5 -
        (xga_20 or 0) * 0.3 -
        (xga_30 or 0) * 0.2
    )

    # 动能指标（最近 3 场 xG 斜率）
    last3 = sub.tail(3)
    if len(last3) >= 3:
        xg_values = last3["xg"].values
        xg_momentum = np.polyfit(range(len(xg_values)), xg_values, 1)[0]
    else:
        xg_momentum = np.nan

    # 防守崩溃指数（最近 5 场 xGA 是否加速）
    last5 = sub.tail(5)
    if len(last5) >= 5:
        xga_values = last5["xga"].values
        xga_collapse = np.polyfit(range(len(xga_values)), xga_values, 1)[0]
    else:
        xga_collapse = np.nan

    return {
        "xg_10": xg_10,
        "xga_10": xga_10,
        "xg_20": xg_20,
        "xga_20": xga_20,
        "xg_30": xg_30,
        "xga_30": xga_30,
        "attack_strength": attack_strength,
        "defense_stability": defense_stability,
        "xg_momentum": xg_momentum,
        "xga_collapse": xga_collapse,
    }
