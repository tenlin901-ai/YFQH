# -*- coding: utf-8 -*-
"""
盘口深度特征（Market Depth Features）
-------------------------------------
用于量化盘口微结构，识别大额盘口动作、庄家差异、赔率群分布、sharp-money 痕迹。

输入：一个盘口价格列表，如 [1.90, 1.88, 1.92, ...]
输出：
- top_k_avg: 前 3 最高赔率平均
- median: 中位数
- max_z, min_z: 赔率分布 z-score 极值
- volatility: 波动率
- liquidity_proxy: 流动性 proxy（盘口是否平稳）
- bookmaker_spread: 最大赔率差 - 最小赔率差
"""

import numpy as np

def depth_stats(prices, top_k=3):
    if not prices or len(prices) == 0:
        return {
            "top_k_avg": None,
            "median": None,
            "max_z": None,
            "min_z": None,
            "volatility": None,
            "liquidity_proxy": None,
            "bookmaker_spread": None,
        }

    arr = np.array(prices, dtype=float)
    arr_sorted = np.sort(arr)

    # 顶级赔率平均（衡量庄家对弱势方的态度）
    k = min(top_k, len(arr_sorted))
    top_k_avg = np.mean(arr_sorted[-k:])

    # 中位数
    median = np.median(arr_sorted)

    # zscore
    std = np.std(arr_sorted) + 1e-9
    zscores = (arr_sorted - median) / std
    max_z = float(np.max(zscores))
    min_z = float(np.min(zscores))

    # 盘口波动率（尖锐变动 = sharp-money）
    volatility = float(std)

    # 流动性 proxy（越小越“平滑”）
    liquidity_proxy = float(np.abs(arr_sorted[-1] - arr_sorted[0]))

    # 最大最小盘差
    bookmaker_spread = float(arr_sorted[-1] - arr_sorted[0])

    return {
        "top_k_avg": float(top_k_avg),
        "median": float(median),
        "max_z": float(max_z),
        "min_z": float(min_z),
        "volatility": float(volatility),
        "liquidity_proxy": float(liquidity_proxy),
        "bookmaker_spread": float(bookmaker_spread),
    }
