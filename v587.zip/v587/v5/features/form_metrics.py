# -*- coding: utf-8 -*-
"""
Form Metrics（球队走势指标）
--------------------------------
描述球队近期走势与整体状态，包括：
- rolling winrate (10/20/30)
- goal difference form
- scoring momentum
- conceding momentum
- defense collapse index
- big chance creation rate
- stability score（综合稳定性）
"""

import numpy as np
import pandas as pd

def safe_mean(x):
    x = [v for v in x if pd.notna(v)]
    return np.mean(x) if x else np.nan

def form_metrics(df, team, dt):
    """
    df 要求包含字段：
        date
        home/away 标识无所谓，只要 team 列统一即可
        gf   (进球)
        ga   (失球)
        xg
        xga
        result (H/A/D)
        big_chances (大机会数)
    """

    sub = df[
        (df["team"] == team) &
        (df["date"] < dt)
    ].sort_values("date")

    if len(sub) == 0:
        return {
            "wr_10": np.nan, "wr_20": np.nan, "wr_30": np.nan,
            "gd_form": np.nan,
            "scoring_momentum": np.nan,
            "conceding_momentum": np.nan,
            "def_collapse_idx": np.nan,
            "big_chance_rate": np.nan,
            "stability_score": np.nan,
        }

    def winrate(N):
        part = sub.tail(N)
        if len(part) == 0: return np.nan
        w = (part["result"] == "W").mean() if "result" in part.columns else np.nan
        return float(w)

    wr_10 = winrate(10)
    wr_20 = winrate(20)
    wr_30 = winrate(30)

    # 进失球趋势
    last5 = sub.tail(5)
    if len(last5) >= 3:
        gf_vals = last5["gf"].values
        ga_vals = last5["ga"].values
        scoring_momentum = float(np.polyfit(range(len(gf_vals)), gf_vals, 1)[0])
        conceding_momentum = float(np.polyfit(range(len(ga_vals)), ga_vals, 1)[0])
    else:
        scoring_momentum = np.nan
        conceding_momentum = np.nan

    # 整体净胜球走势（最近 10 场净胜球平均）
    last10 = sub.tail(10)
    gd_form = safe_mean(last10["gf"] - last10["ga"]) if len(last10) else np.nan

    # 防线崩盘指数（最近 5 场 xGA 是否增加）
    if len(last5) >= 5:
        xga_vals = last5["xga"].values
        def_collapse_idx = float(np.polyfit(range(len(xga_vals)), xga_vals, 1)[0])
    else:
        def_collapse_idx = np.nan

    # 大机会创造率（big chances per match）
    if "big_chances" in sub.columns:
        bc = safe_mean(sub.tail(10)["big_chances"])
        big_chance_rate = float(bc) if bc is not None else np.nan
    else:
        big_chance_rate = np.nan

    # 稳定性评分（越稳定越接近 1）
    stability_score = float(
        (1 - abs(def_collapse_idx or 0) / 5) * 0.5 +
        (wr_10 or 0) * 0.3 +
        (gd_form or 0) / 5 * 0.2
    )

    return {
        "wr_10": wr_10,
        "wr_20": wr_20,
        "wr_30": wr_30,
        "gd_form": gd_form,
        "scoring_momentum": scoring_momentum,
        "conceding_momentum": conceding_momentum,
        "def_collapse_idx": def_collapse_idx,
        "big_chance_rate": big_chance_rate,
        "stability_score": stability_score,
    }
