# -*- coding: utf-8 -*-
"""
train_meta_ensemble.py
----------------------
多模型融合 (Stacked Ensemble)
将以下模型融合成一个 meta-model：
- Logistic Regression
- GradientBoostingClassifier
- XGBoost (可选)
- LightGBM (可选)
融合后输出：meta_model.pkl
"""

import numpy as np
import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier

try:
    from xgboost import XGBClassifier
    XGB_AVAILABLE = True
except:
    XGB_AVAILABLE = False

try:
    from lightgbm import LGBMClassifier
    LGB_AVAILABLE = True
except:
    LGB_AVAILABLE = False


def load_dataset():
    """
    使用 data/strategy_dataset.csv 作为基础特征
    必须有字段：
        p_model（模型原始概率）
        ev_mag
        elo_diff_pre
        home_recent_winrate
        ...

    这里不做重特征处理，只做融合训练
    """
    df = pd.read_csv("data/strategy_dataset.csv")
    df = df.dropna()

    feature_cols = [c for c in df.columns if c not in ["y"]]
    X = df[feature_cols].values
    y = df["y"].astype(int).values

    return X, y, feature_cols


def make_base_models():
    """
    基础模型集成
    """
    models = {}

    # 1. GBM
    models["gbm"] = GradientBoostingClassifier(
        n_estimators=300,
        learning_rate=0.05,
        max_depth=3,
        subsample=0.9
    )

    # 2. Random Forest
    models["rf"] = RandomForestClassifier(
        n_estimators=300,
        max_depth=6,
        min_samples_leaf=10
    )

    # 3. Logistic Regression
    models["lr"] = LogisticRegression(max_iter=300)

    # 4. XGBoost (如果安装)
    if XGB_AVAILABLE:
        models["xgb"] = XGBClassifier(
            n_estimators=300,
            max_depth=4,
            learning_rate=0.04,
            subsample=0.9,
            colsample_bytree=0.8,
        )

    # 5. LightGBM (如果安装)
    if LGB_AVAILABLE:
        models["lgb"] = LGBMClassifier(
            n_estimators=300,
            max_depth=-1,
            learning_rate=0.03,
            subsample=0.9,
            colsample_bytree=0.8,
        )

    return models


def train_meta_model(meta_X, meta_y):
    """
    Meta-Model（使用简单稳定的 LR）
    """
    meta = LogisticRegression(max_iter=500)
    meta.fit(meta_X, meta_y)
    return meta


def main():
    X, y, feature_cols = load_dataset()

    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=42)

    models = make_base_models()
    oof_preds = []

    for name, mdl in models.items():
        print("Training base model:", name)
        mdl.fit(Xtr, ytr)

        # 保存 base model
        joblib.dump(mdl, f"models/base_{name}.pkl")

        # out-of-fold prediction（用于 meta）
        pred = mdl.predict_proba(Xte)[:, 1]
        oof_preds.append(pred)

    # 合并 base model 输出
    meta_X = np.vstack(oof_preds).T
    meta_y = yte

    # 训练 Meta 模型
    print("Training META-MODEL...")
    meta_model = train_meta_model(meta_X, meta_y)

    joblib.dump({
        "meta_model": meta_model,
        "base_models": list(models.keys()),
        "feature_cols": feature_cols
    }, "models/meta_model.pkl")

    print("saved models/meta_model.pkl")


if __name__ == "__main__":
    main()
