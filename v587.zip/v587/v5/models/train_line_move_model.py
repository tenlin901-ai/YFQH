# -*- coding: utf-8 -*-
"""
train_line_move_model.py
------------------------
盘口走势预测模型（Line Movement Prediction Model）

目标：
预测未来 30 分钟盘口是否会继续朝某个方向移动（例如 AH -0.25 -> -0.5）。
steam move（资金流）通常在主力消息、赔率失衡时发生，因此提前预测可极大提升盈利能力。

输入数据要求：
data/line_movement_dataset.csv
字段包括：
    timestamp
    match_id
    bookmaker
    home_odds
    away_odds
    line
    next_30m_line
    next_30m_move_up (0/1)

训练输出：
models/line_move_model.pkl
"""

import numpy as np
import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

def prepare_features(df):
    """
    构造盘口波动特征：
    - odds_diff: home_odds - away_odds
    - volatility: 短期盘口波动率
    - drift: 连续 3 个时间点方向变化
    - bookmaker_consensus: 各庄家盘口共识程度
    """

    df = df.copy()

    df["odds_diff"] = df["home_odds"] - df["away_odds"]
    df["abs_diff"] = df["odds_diff"].abs()

    # 简易 volatility（最好用 minute-level tick）
    df["volatility"] = (
        df["home_odds"].rolling(3).std().fillna(0) +
        df["away_odds"].rolling(3).std().fillna(0)
    )

    # 趋势 drift（过去 3 个 tick 是否一致）
    df["drift"] = np.sign(df["odds_diff"].diff().fillna(0))
    df["drift3"] = (
        np.sign(df["odds_diff"].diff(1).fillna(0)) +
        np.sign(df["odds_diff"].diff(2).fillna(0)) +
        np.sign(df["odds_diff"].diff(3).fillna(0))
    )

    # bookmaker consensus（越接近说明盘口一致性越强）
    # 简化：使用全局中位数差
    df["bm_consensus"] = df["abs_diff"].expanding().mean()

    # 输入特征
    X = df[[
        "home_odds",
        "away_odds",
        "line",
        "odds_diff",
        "abs_diff",
        "volatility",
        "drift",
        "drift3",
        "bm_consensus",
    ]].values

    return X

def main():
    path = "data/line_movement_dataset.csv"
    if not os.path.exists(path):
        print("no line movement dataset")
        return

    df = pd.read_csv(path)
    df = df.dropna(subset=["next_30m_move_up"])

    y = df["next_30m_move_up"].astype(int).values
    X = prepare_features(df)

    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=42)

    model = Pipeline([
        ("scaler", StandardScaler()),
        ("gbm", GradientBoostingClassifier(
            n_estimators=400,
            learning_rate=0.04,
            max_depth=3,
            subsample=0.8
        ))
    ])

    model.fit(Xtr, ytr)

    joblib.dump({"pipeline": model}, "models/line_move_model.pkl")
    print("saved models/line_move_model.pkl")

if __name__ == "__main__":
    import os
    main()
