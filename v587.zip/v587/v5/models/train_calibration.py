# -*- coding: utf-8 -*-
"""
train_calibration.py
--------------------
对模型输出概率进行多方法组合校准：
- Platt scaling (Logistic Regression)
- Isotonic Regression
- Beta Calibration
最终输出综合校准模型：calibration_model.pkl
"""

import numpy as np
import pandas as pd
import joblib

from sklearn.linear_model import LogisticRegression
from sklearn.isotonic import IsotonicRegression
from sklearn.model_selection import train_test_split
from sklearn.base import BaseEstimator, ClassifierMixin

# --------------------------
# Beta Calibration (multiclass not needed)
# --------------------------
class BetaCalibrator(BaseEstimator, ClassifierMixin):
    def __init__(self):
        self.a = None
        self.b = None

    def fit(self, p, y):
        """
        Beta calibration:
        log(p / (1 - p)) = a * logit(p) + b
        """
        eps = 1e-9
        p = np.clip(p, eps, 1 - eps)
        logit = np.log(p / (1 - p))

        X = logit.reshape(-1, 1)
        y = np.array(y)

        # simple linear regression
        self.a, self.b = np.polyfit(logit, y, 1)
        return self

    def predict(self, p):
        eps = 1e-9
        p = np.clip(p, eps, 1 - eps)
        logit = np.log(p / (1 - p))
        cal = self.a * logit + self.b
        return float(1 / (1 + np.exp(-cal)))


# --------------------------
# 综合校准器
# --------------------------
class CombinedCalibrator:
    def __init__(self, lr, iso, beta):
        self.lr = lr
        self.iso = iso
        self.beta = beta

    def predict(self, p):
        # individual
        lr_p = float(self.lr.predict_proba([[p]])[0, 1])
        iso_p = float(self.iso.predict([p])[0])
        beta_p = float(self.beta.predict(p))

        # weighted ensemble
        return float(0.45 * lr_p + 0.35 * iso_p + 0.20 * beta_p)


# --------------------------
# 主训练流程
# --------------------------
def main():
    df = pd.read_csv("data/strategy_dataset.csv")

    df = df.dropna(subset=["p_model", "y"])
    p = df["p_model"].values
    y = df["y"].astype(int).values

    # train-test split
    p_train, p_test, y_train, y_test = train_test_split(p, y, test_size=0.2, random_state=42)

    # 1. Platt scaling
    lr = LogisticRegression()
    lr.fit(p_train.reshape(-1, 1), y_train)

    # 2. Isotonic regression
    iso = IsotonicRegression(out_of_bounds="clip")
    iso.fit(p_train, y_train)

    # 3. Beta calibration
    beta = BetaCalibrator()
    beta.fit(p_train, y_train)

    # 4. Combined calibrator
    cal = CombinedCalibrator(lr, iso, beta)

    # 保存
    joblib.dump({
        "calibrator": cal,
        "lr": lr,
        "iso": iso,
        "beta": beta
    }, "models/calibration_model.pkl")

    print("saved models/calibration_model.pkl")


if __name__ == "__main__":
    main()
