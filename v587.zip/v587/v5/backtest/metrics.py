# -*- coding: utf-8 -*-
"""
metrics.py (Advanced Risk Metrics)
-----------------------------------
提供高级风险与稳定性指标，用于评估量化策略表现。

指标包括：
- rolling_sharpe
- rolling_max_drawdown
- ulcer_index
- calmar_ratio
- recovery_factor
- drawdown_duration
- volatility_clustering
"""

import numpy as np
import pandas as pd

# -----------------------------
# Rolling Sharpe
# -----------------------------
def rolling_sharpe(returns, window=20):
    """
    returns: 每笔交易收益率 pnl/stake
    window: 滚动窗口
    """
    rs = []
    for i in range(len(returns)):
        if i < window:
            rs.append(np.nan)
            continue
        segment = returns[i-window:i]
        sharpe = np.mean(segment) / (np.std(segment) + 1e-9)
        rs.append(sharpe)
    return rs


# -----------------------------
# Rolling Max Drawdown
# -----------------------------
def rolling_max_drawdown(equity, window=50):
    mdd_list = []
    for i in range(len(equity)):
        if i < window:
            mdd_list.append(np.nan)
            continue
        segment = equity[i-window:i]
        peak = np.maximum.accumulate(segment)
        dd = (segment - peak) / peak
        mdd_list.append(np.min(dd))
    return mdd_list


# -----------------------------
# Ulcer Index（溃疡指数）
# -----------------------------
def ulcer_index(equity):
    """
    Ulcer Index = sqrt(average drawdown^2)
    """
    equity = np.array(equity)
    peak = np.maximum.accumulate(equity)
    dd = (equity - peak) / peak
    ui = np.sqrt(np.mean(dd**2))
    return float(ui)


# -----------------------------
# Calmar Ratio
# -----------------------------
def calmar_ratio(annualized_return, max_drawdown):
    """
    Calmar = 年化收益 / 最大回撤
    """
    if max_drawdown == 0:
        return np.nan
    return float(annualized_return / abs(max_drawdown))


# -----------------------------
# Recovery Factor（回撤恢复因子）
# -----------------------------
def recovery_factor(total_return, max_drawdown):
    """
    Recovery Factor = 总收益 / 最大回撤
    """
    if max_drawdown == 0:
        return np.nan
    return float(total_return / abs(max_drawdown))


# -----------------------------
# Drawdown Duration（回撤时间长度）
# -----------------------------
def drawdown_duration(equity):
    """
    计算连续处于 drawdown 状态的最长持续时间
    """
    equity = np.array(equity)
    peak = np.maximum.accumulate(equity)
    dd = (equity - peak) / peak

    duration = 0
    max_duration = 0

    for d in dd:
        if d < 0:
            duration += 1
            max_duration = max(max_duration, duration)
        else:
            duration = 0

    return int(max_duration)


# -----------------------------
# Volatility Clustering（波动聚集）
# -----------------------------
def volatility_clustering(returns, window=20):
    """
    测试波动是否聚集（ARCH/GARCH 常见特征）：
    统计 rolling std 是否呈现连续高位。
    """
    vol = pd.Series(returns).rolling(window).std()
    # 检查高波动持续时间
    threshold = vol.mean() + vol.std()
    clusters = (vol > threshold).astype(int)
    return clusters.sum()
