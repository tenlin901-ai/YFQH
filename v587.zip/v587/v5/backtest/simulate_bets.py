# -*- coding: utf-8 -*-
"""
simulate_bets.py
----------------
将策略信号（signals）转换为回测引擎所需的标准下注记录格式。

输入：
    df_signals_raw（来自策略层输出）
    df_matches（包含 match_id + 队伍对应信息）
输出：
    df_signals_backtest（包含 stake/odds/side/match_id）

可选功能：
- 应用风控（可选）
- 执行组合凯利（可选）
"""

import pandas as pd
import numpy as np

from v5.strategy.portfolio_kelly import portfolio_kelly
from v5.strategy.risk_limits import RiskEngine

def prepare_backtest_signals(
    df_signals_raw,
    df_matches,
    bankroll,
    apply_risk=True,
    apply_kelly=False
):
    """
    转换 signal → backtest 格式

    df_signals_raw：
        match_id
        p_model
        p_calibrated
        ev
        side
        odds
        stake (optional)

    df_matches：
        match_id
        home
        away
        league
        kickoff

    返回：
        df_backtest
    """

    # merge signals with match metadata
    df = pd.merge(df_signals_raw, df_matches, on="match_id", how="left")

    # 风控引擎
    risk = RiskEngine(bankroll) if apply_risk else None

    backtest_rows = []

    for _, row in df.iterrows():

        match_id = row["match_id"]
        side     = row["side"]
        odds     = float(row["odds"])
        p_mod    = float(row["p_model"])
        p_cal    = float(row["p_calibrated"])
        ev       = float(row["ev"])

        # 下注额
        if apply_kelly:
            # 简化使用单笔凯利分配
            stake_pct = max(0.01, min(0.10, (p_cal * odds - (1 - p_cal)) / (odds - 1)))
            stake = bankroll * stake_pct
        else:
            stake = row.get("stake", bankroll * 0.02)  # default 2%

        # 风控过滤
        if apply_risk:
            if not risk.approve(
                stake=stake,
                ev=ev,
                p_model=p_mod,
                p_calibrated=p_cal
            ):
                # 风控拒绝，无下注
                continue

        backtest_rows.append({
            "match_id": match_id,
            "side": side,
            "stake": float(stake),
            "odds": float(odds),
            "p_model": p_mod,
            "p_calibrated": p_cal,
            "ev": ev,
        })

    return pd.DataFrame(backtest_rows)
