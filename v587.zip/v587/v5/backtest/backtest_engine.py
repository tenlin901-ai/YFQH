# -*- coding: utf-8 -*-
"""
backtest_engine.py
------------------
专业量化级别回测引擎，用于在历史数据上模拟下注流程。

功能：
- 加载历史盘口
- 加载模型预测概率
- 加载策略信号
- 执行下注模拟
- 计算盈亏 PnL
- 生成 equity curve（账户曲线）
- 可扩展滑点、延迟、成交量等真实因素
"""

import pandas as pd
import numpy as np

class BacktestEngine:
    def __init__(self, initial_bankroll=10000, slip_pct=0.00):
        """
        slip_pct: 滑点百分比（如 0.01 = 下单价格上涨 1%）
        """
        self.initial_bankroll = initial_bankroll
        self.bankroll = initial_bankroll
        self.slip_pct = slip_pct

        self.trades = []

    def apply_slippage(self, odds):
        """
        模拟交易滑点，只增不减（真实世界下注限制）
        """
        return odds * (1 - self.slip_pct)

    def place_bet(self, match_id, side, stake, odds, result):
        """
        result = 1/0 (赢/输)
        """

        # 滑点影响
        exec_odds = self.apply_slippage(odds)

        if result == 1:
            pnl = stake * (exec_odds - 1)
        else:
            pnl = -stake

        self.bankroll += pnl

        self.trades.append({
            "match_id": match_id,
            "side": side,
            "stake": stake,
            "odds": exec_odds,
            "pnl": pnl,
            "bankroll": self.bankroll
        })

    def run(self, df_signals, df_results):
        """
        df_signals 必须包含：
            match_id
            side
            stake
            odds
        df_results 必须包含：
            match_id
            result (1/0)
        """
        df = pd.merge(df_signals, df_results, on="match_id", how="inner")

        for _, row in df.iterrows():
            self.place_bet(
                match_id=row["match_id"],
                side=row["side"],
                stake=row["stake"],
                odds=row["odds"],
                result=row["result"]
            )

        return pd.DataFrame(self.trades)

    def equity_curve(self):
        if not self.trades:
            return None
        df = pd.DataFrame(self.trades)
        return df[["bankroll"]]
