# -*- coding: utf-8 -*-
"""
evaluate_performance.py
------------------------
用于评估策略回测结果的专业绩效指标，包括：

- ROI（总收益率）
- Annualized Return（年化收益）
- Sharpe Ratio
- Max Drawdown（最大回撤）
- Volatility（波动率）
- Hit Rate（胜率）
- Profit Factor（盈利因子）
- Expectancy（期望收益）
- Equity Curve（账户曲线）

输入：
    df_trades：backtest_engine 生成的交易记录 DataFrame

输出：
    dict 指标集合
"""

import numpy as np
import pandas as pd

def max_drawdown(equity):
    """
    最大回撤（Max Drawdown）
    """
    equity = np.array(equity)
    peak = np.maximum.accumulate(equity)
    dd = (equity - peak) / peak
    return float(dd.min())

def sharpe_ratio(returns, rf=0.0):
    """
    夏普比率（Sharpe Ratio）
    returns 为每笔交易的百分比收益 (pnl / stake)
    """
    if len(returns) < 2:
        return np.nan
    excess = returns - rf
    return float(np.mean(excess) / (np.std(excess) + 1e-9))

def evaluate_performance(df_trades, initial_bankroll=10000):
    """
    df_trades 必须包含:
        pnl
        stake
        bankroll
    """

    if df_trades is None or len(df_trades) == 0:
        return {
            "roi": np.nan,
            "annualized_return": np.nan,
            "sharpe": np.nan,
            "max_drawdown": np.nan,
            "hit_rate": np.nan,
            "profit_factor": np.nan,
            "expectancy": np.nan,
            "num_trades": 0
        }

    df = df_trades.copy()

    # 1. ROI（总收益率）
    final_equity = df["bankroll"].iloc[-1]
    roi = (final_equity - initial_bankroll) / initial_bankroll

    # 2. Annualized（假设一年 250 个交易日）
    num_trades = len(df)
    daily_return = roi / max(1, num_trades / 250)
    annualized_return = daily_return * 250

    # 3. 每笔收益比例
    returns = df["pnl"] / df["stake"].replace(0, np.nan)

    # 4. 夏普比率
    sharpe = sharpe_ratio(returns.values)

    # 5. 最大回撤
    mdd = max_drawdown(df["bankroll"].values)

    # 6. 胜率（Hit rate）
    hit_rate = (df["pnl"] > 0).mean()

    # 7. 盈利因子（Profit Factor）
    gross_profit = df[df["pnl"] > 0]["pnl"].sum()
    gross_loss = -df[df["pnl"] < 0]["pnl"].sum()
    profit_factor = gross_profit / (gross_loss + 1e-9)

    # 8. Expectancy（期望收益）
    expectancy = (gross_profit - gross_loss) / max(1, num_trades)

    return {
        "roi": float(roi),
        "annualized_return": float(annualized_return),
        "sharpe": float(sharpe),
        "max_drawdown": float(mdd),
        "hit_rate": float(hit_rate),
        "profit_factor": float(profit_factor),
        "expectancy": float(expectancy),
        "num_trades": int(num_trades),
        "final_equity": float(final_equity)
    }
