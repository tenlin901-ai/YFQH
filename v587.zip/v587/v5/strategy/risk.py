# -*- coding: utf-8 -*-
"""
risk_limits.py
----------------
风控系统（Risk Management Engine）
用于控制下注风险、避免爆仓、规避黑天鹅。
包含：
- daily loss limit (每日最大亏损)
- max exposure per match (每场最大敞口)
- losing streak protection (连输保护)
- model drift alert (模型偏移检测)
- bankroll max stake limit (资金最大下注比例)
"""

import numpy as np
import pandas as pd
import os
from datetime import datetime, timedelta

DEFAULT_CONFIG = {
    "max_daily_loss_pct": 0.15,      # 单日最大回撤 15%
    "max_match_exposure_pct": 0.08,  # 单场最大风险敞口 8%
    "losing_streak_limit": 5,        # 最多允许连续 5 场亏损
    "max_stake_pct": 0.10,           # 最大下注不超过资金 10%
    "min_ev_requirement": 0.02,      # EV 二次最低要求
    "drift_threshold": 0.10,         # 预测偏差大于 10% 报警
}

class RiskEngine:
    def __init__(self, bankroll, log_path="data/signals_log_v5.csv", cfg=DEFAULT_CONFIG):
        self.bankroll = bankroll
        self.log_path = log_path
        self.cfg = cfg

    # --------------------
    # 1. 每日回撤限制
    # --------------------
    def check_daily_loss(self):
        if not os.path.exists(self.log_path):
            return True  # 无记录

        df = pd.read_csv(self.log_path)
        df["ts"] = pd.to_datetime(df["ts"], errors="coerce")

        today = datetime.now().date()
        today_df = df[df["ts"].dt.date == today]

        if today_df.empty:
            return True

        pnl = today_df["pnl"].sum() if "pnl" in today_df.columns else 0
        if pnl < -self.bankroll * self.cfg["max_daily_loss_pct"]:
            print("[RISK] Daily loss limit reached.")
            return False

        return True

    # --------------------
    # 2. 单场敞口限制
    # --------------------
    def check_exposure(self, stake):
        if stake > self.bankroll * self.cfg["max_match_exposure_pct"]:
            print("[RISK] Stake exceeds max match exposure.")
            return False
        return True

    # --------------------
    # 3. 连续亏损保护
    # --------------------
    def check_losing_streak(self):
        if not os.path.exists(self.log_path):
            return True

        df = pd.read_csv(self.log_path)
        if "pnl" not in df.columns:
            return True

        # 最近 10 场
        last10 = df.tail(10)
        losses = (last10["pnl"] < 0).sum()

        if losses >= self.cfg["losing_streak_limit"]:
            print("[RISK] Losing streak limit reached.")
            return False

        return True

    # --------------------
    # 4. EV 二次确认
    # --------------------
    def check_ev_requirement(self, ev):
        if ev < self.cfg["min_ev_requirement"]:
            print("[RISK] EV below requirement.")
            return False
        return True

    # --------------------
    # 5. 最大下注比例限制
    # --------------------
    def check_max_stake(self, stake):
        if stake > self.bankroll * self.cfg["max_stake_pct"]:
            print("[RISK] Stake > max_stake_pct limit.")
            return False
        return True

    # --------------------
    # 6. 模型偏移检测
    # --------------------
    def check_model_drift(self, p_model, p_calibrated):
        drift = abs(p_calibrated - p_model)
        if drift > self.cfg["drift_threshold"]:
            print(f"[RISK] Model drift detected ({drift:.3f})")
            return False
        return True

    # --------------------
    # 总检查
    # --------------------
    def approve(self, stake, ev, p_model, p_calibrated):
        return (
            self.check_daily_loss() and
            self.check_exposure(stake) and
            self.check_losing_streak() and
            self.check_ev_requirement(ev) and
            self.check_max_stake(stake) and
            self.check_model_drift(p_model, p_calibrated)
        )
