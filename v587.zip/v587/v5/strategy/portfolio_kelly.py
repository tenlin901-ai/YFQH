# -*- coding: utf-8 -*-
"""
portfolio_kelly.py
-------------------
组合凯利下注（Portfolio Kelly Betting）

输入：
- ps: 概率列表，如 [0.56, 0.60, 0.58]
- odds: 赔率列表，如 [1.95, 2.05, 1.90]

输出：
- kelly 向量，如 [0.018, 0.022, 0.015]
表示每场分别下 bankroll * weight
"""

import numpy as np

def portfolio_kelly(ps, odds):
    ps = np.array(ps, dtype=float)
    odds = np.array(odds, dtype=float)

    qs = 1 - ps
    bs = odds - 1.0

    # 单凯利项
    frac = (ps * bs - qs) / bs
    frac = np.clip(frac, 0, 1)

    # 归一化（组合方式）
    if frac.sum() > 1:
        frac = frac / frac.sum()

    # 最终下注比例
    return frac.tolist()
