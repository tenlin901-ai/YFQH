# -*- coding: utf-8 -*-
"""
policy_model.py
----------------
策略决策模型（Policy Decision Model）

作用：
- 判断是否下注
- 根据校准概率、EV、盘口动向等综合评分
"""

def policy_decision(p_cal, ev, move_prob, vol, p_final):
    """
    输入：
    - p_cal: 校准后概率
    - ev: 期望收益
    - move_prob: 盘口未来走势概率（是否朝本方移动）
    - vol: 波动率
    - p_final: 最终概率用于加权

    输出：
        True / False（是否下注）
    """

    # 综合评分（权重可调）
    score = (
        0.45 * p_cal +
        0.25 * ev +
        0.20 * (move_prob - 0.5) +
        0.10 * (1 / (1 + vol))
    )

    return score > 0.60
