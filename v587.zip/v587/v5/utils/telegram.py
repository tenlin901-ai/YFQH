# -*- coding: utf-8 -*-
"""
telegram.py
------------
负责 Telegram 消息推送。
"""

import requests

def tg_send(bot_token, chat_id, text):
    try:
        url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
        r = requests.post(url, data={"chat_id": chat_id, "text": text})
        return r.status_code
    except Exception as e:
        print("[TG ERROR]", e)
        return None
