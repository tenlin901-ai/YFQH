# -*- coding: utf-8 -*-
"""
data_loader.py
----------------
所有数据的统一加载接口：
- 历史比赛数据
- 赔率数据
- xG 数据
- 球员状态数据
- 天气数据
- 策略数据

提供：
    safe_load_csv(path)
    load_match_data()
    load_player_data()
    load_xg_data()
    load_weather_data()
    load_strategy_dataset()

所有加载的数据都会：
- 去掉空行
- 修正日期格式
- 标准化列名（全部小写）
"""

import pandas as pd
import numpy as np
import os

def safe_load_csv(path, parse_dates=None):
    if not os.path.exists(path):
        print(f"[WARN] Missing file: {path}")
        return pd.DataFrame()

    try:
        df = pd.read_csv(path)
    except:
        print(f"[WARN] CSV load failure: {path}")
        return pd.DataFrame()

    # 清洗
    df = df.dropna(how="all")
    df.columns = [c.lower().strip() for c in df.columns]

    if parse_dates:
        for col in parse_dates:
            if col in df.columns:
                df[col] = pd.to_datetime(df[col], errors="coerce")

    return df


# ------------------------------
# 数据加载接口
# ------------------------------

def load_match_data():
    return safe_load_csv("data/matches.csv", parse_dates=["date", "kickoff"])

def load_player_data():
    return safe_load_csv("data/players.csv", parse_dates=["date"])

def load_xg_data():
    return safe_load_csv("data/xg_data.csv", parse_dates=["date"])

def load_weather_data():
    return safe_load_csv("data/weather.csv", parse_dates=["date"])

def load_strategy_dataset():
    return safe_load_csv("data/strategy_dataset.csv")
