# -*- coding: utf-8 -*-
"""
calibration.py
---------------
加载训练好的校准模型，并提供统一的 apply_calibration(p) 接口。

支持：
- Logistic Regression 校准
- Isotonic 校准
- Beta 校准
- 综合加权校准
"""

import joblib
import numpy as np

MODEL_PATH = "models/calibration_model.pkl"

def apply_calibration(p):
    """
    p: 原始模型概率（0~1）
    """
    if not 0 <= p <= 1:
        return p

    try:
        bundle = joblib.load(MODEL_PATH)
        cal = bundle["calibrator"]
        return float(cal.predict(p))
    except:
        # 如果模型缺失，则直接返回原值
        return float(p)
