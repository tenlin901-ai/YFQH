# -*- coding: utf-8 -*-
"""
time_utils.py
--------------
管理时区、时间格式、ISO 时间解析等。
"""

from datetime import datetime, timezone, timedelta

def make_timezone(offset_hours):
    return timezone(timedelta(hours=offset_hours))

def parse_iso(dt_str, tz):
    try:
        return datetime.fromisoformat(dt_str.replace("Z", "+00:00")).astimezone(tz)
    except:
        return None
