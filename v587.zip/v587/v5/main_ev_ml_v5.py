# -*- coding: utf-8 -*-
"""
v5 Betting Engine - 完整功能版（与你当前工程完全匹配）
"""
import os
import time
import yaml
from datetime import datetime

# ===== Utils =====
from v5.utils.time_utils import make_timezone
from v5.utils.telegram import tg_send
from v5.utils.calibration import apply_calibration
from v5.utils.data_loader import (
    load_match_data,
    load_player_data,
    load_xg_data,
    load_weather_data
)

# ===== Core =====
from v5.core.loader import load_all_models
from v5.core.odds_loader import fetch_all_odds, league_map
from v5.core.logger import log_signal

# ===== Strategy =====
from v5.strategy.risk import RiskEngine
from v5.strategy.portfolio_kelly import portfolio_kelly
from v5.strategy.policy_model import policy_decision

# ===== Features =====
from v5.features.agg_depth import depth_stats
from v5.features.xg_features import rolling_xg_features
from v5.features.form_metrics import form_metrics
from v5.features.player_status import analyze_player_status
from v5.features.weather import weather_features


# ========== 加载配置 ==========
cfg = yaml.safe_load(open("config.yaml", encoding="utf-8"))

SPORTS = cfg["odds_api"]["sports"]
REGION = cfg["odds_api"]["region"]
API_KEY = cfg["odds_api"]["api_key"]

BOT_TOKEN = cfg["telegram"]["bot_token"]
CHAT_ID = cfg["telegram"]["chat_id"]

EV_THRESHOLD = cfg["strategy"]["ev_threshold_ah"]
REFRESH = cfg["strategy"]["refresh_interval"]
BANKROLL = cfg["strategy"]["bankroll"]
KELLY_FACTOR = cfg["strategy"]["kelly_factor"]

TZ = make_timezone(cfg["timezone"]["offset_hours"])
LOG_PATH = "data/signals_log_v5.csv"


# ========== 加载数据 ==========
MATCH_DATA = load_match_data()
PLAYER_DATA = load_player_data()
XG_DATA = load_xg_data()
WEATHER_DATA = load_weather_data()


# ========== 聚合函数 ==========
def remove_vig(h, d, a):
    try:
        inv = [1/h, 1/d, 1/a]
        s = sum(inv)
        return inv[0]/s, inv[1]/s, inv[2]/s
    except:
        return None, None, None


def aggregate_h2h(game, home, away):
    prices_h, prices_d, prices_a = [], [], []

    for b in game.get("bookmakers", []):
        for m in b.get("markets", []):
            if m.get("key") != "h2h":
                continue
            for o in m.get("outcomes", []):
                name = o.get("name","").lower()
                price = o.get("price")
                if price is None:
                    continue
                price = float(price)
                if "draw" in name:
                    prices_d.append(price)
                elif home.lower() in name:
                    prices_h.append(price)
                elif away.lower() in name:
                    prices_a.append(price)

    if not prices_h or not prices_d or not prices_a:
        return None

    return (
        float(np.median(prices_h)),
        float(np.median(prices_d)),
        float(np.median(prices_a)),
    )


def aggregate_spreads(game, home, away):
    result = {}
    for b in game.get("bookmakers", []):
        for m in b.get("markets", []):
            if m.get("key") != "spreads":
                continue
            for o in m.get("outcomes", []):
                name = o.get("name","").lower()
                price = o.get("price")
                point = o.get("point")
                if price is None or point is None:
                    continue
                price = float(price)
                point = float(point)
                if home.lower() in name:
                    result.setdefault(point,{})["home"] = price
                elif away.lower() in name:
                    result.setdefault(point,{})["away"] = price

    out = {}
    for L, d in result.items():
        if "home" in d and "away" in d:
            out[L] = d
    return out


# ========== 单场分析 ==========
def analyze_game(game, league, models):

    home = game["home_team"]
    away = game["away_team"]

    # 时间解析
    dt_str = game.get("commence_time")
    if dt_str is None:
        return []

    h2h = aggregate_h2h(game, home, away)
    if not h2h:
        return []

    pi_home, pi_draw, pi_away = remove_vig(*h2h)

    spreads = aggregate_spreads(game, home, away)
    if not spreads:
        return []

    signals = []

    for line, od in spreads.items():
        odds_home = od["home"]
        odds_away = od["away"]

        # Features
        feats = {
            "prob_home_h2h": pi_home,
            "prob_away_h2h": pi_away,
            "odds_home": odds_home,
            "odds_away": odds_away,
            "line": line,
        }

        feats.update({"home_"+k: v for k,v in rolling_xg_features(XG_DATA, home, dt_str).items()})
        feats.update({"away_"+k: v for k,v in rolling_xg_features(XG_DATA, away, dt_str).items()})

        feats.update({"home_"+k: v for k,v in analyze_player_status(PLAYER_DATA, home, dt_str).items()})
        feats.update({"away_"+k: v for k,v in analyze_player_status(PLAYER_DATA, away, dt_str).items()})

        feats.update({"home_"+k: v for k,v in form_metrics(MATCH_DATA, home, dt_str).items()})
        feats.update({"away_"+k: v for k,v in form_metrics(MATCH_DATA, away, dt_str).items()})

        feats.update(weather_features(WEATHER_DATA))

        # AH 模型
        ah_model = models["ah_models"].get(league)
        if ah_model is None:
            continue

        X = np.array([[feats.get(c,0) for c in ah_model["feature_cols"]]], float)
        p_raw = ah_model["pipeline"].predict_proba(X)[0,1]

        # 校准
        p_cal = apply_calibration(p_raw)

        # EV
        ev = p_cal * odds_home - 1

        if ev >= EV_THRESHOLD:
            signals.append({
                "league": league,
                "home": home,
                "away": away,
                "side": "home",
                "line": line,
                "odds": odds_home,
                "p_cal": p_cal,
                "ev": ev,
                "move_prob": 0.5,
            })

    return signals


# ========== 主循环 ==========
def main_loop():

    tg_send(BOT_TOKEN, CHAT_ID, "🚀 系统启动成功！")

    # 加载模型（AH 模型）
    ah_models = {}
    all_models = load_all_models()
    all_models["ah_models"] = ah_models

    risk = RiskEngine(BANKROLL)

    while True:
        try:
            odds_batch = fetch_all_odds(SPORTS, API_KEY, REGION)

            for sport_key, games in odds_batch.items():

                league = league_map.get(sport_key)
                if league is None:
                    continue

                # 加载 AH 模型
                path = f"models/ah_model_{league}.pkl"
                if os.path.exists(path):
                    ah_models[league] = joblib.load(path)

                for game in games:

                    sigs = analyze_game(game, league, all_models)
                    if not sigs:
                        continue

                    # Kelly
                    final = portfolio_kelly(sigs, BANKROLL, KELLY_FACTOR)

                    # Risk filter
                    final = [s for s in final if risk.approve(
                        s["stake"], s["ev"], s["p_cal"], s["p_cal"]
                    )]

                    # 推送
                    for s in final:
                        txt = (
                            f"🏆 {s['league']} {s['home']} vs {s['away']}\n"
                            f"方向：{s['side']} 盘口 {s['line']:+.2f}\n"
                            f"p={s['p_cal']:.3f}  EV={s['ev']:.3f}\n"
                            f"下注：${s['stake']:.2f}"
                        )
                        tg_send(BOT_TOKEN, CHAT_ID, txt)
                        log_signal(s, LOG_PATH)

            time.sleep(REFRESH)

        except Exception as e:
            tg_send(BOT_TOKEN, CHAT_ID, f"⚠️ 错误: {e}")
            time.sleep(60)


if __name__ == "__main__":
    main_loop()
