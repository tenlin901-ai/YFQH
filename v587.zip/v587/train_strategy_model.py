# -*- coding: utf-8 -*-
import os, joblib
import pandas as pd
import numpy as np
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

DATA_PATH = "data/strategy_dataset.csv"
MODEL_PATH = "models/strategy_model_v2.pkl"

def main():
    if not os.path.exists(DATA_PATH):
        print("strategy_dataset.csv missing")
        return

    df = pd.read_csv(DATA_PATH)
    cols = [
        "side_home_flag",
        "line_used",
        "odds_used",
        "p_model",
        "ev_mag",
        "elo_diff_pre",
        "elo_home_trend",
        "elo_away_trend",
        "home_recent_winrate",
        "away_recent_winrate",
        "home_scored_recent",
        "home_conceded_recent",
        "away_scored_recent",
        "away_conceded_recent",
        "home_rest_days",
        "away_rest_days",
        "fav_is_home",
        "prob_spread_home_away",
        "market_spread_h",
        "market_spread_a",
        "market_spread_maxmin",
        "y",
    ]

    df = df.dropna(subset=cols)
    X = df[[c for c in cols if c != "y"]].values
    y = df["y"].astype(int).values

    pipe = Pipeline([
        ("scaler", StandardScaler()),
        ("gbm", GradientBoostingClassifier(
            n_estimators=300,
            learning_rate=0.05,
            max_depth=3,
            subsample=0.8,
        ))
    ])

    pipe.fit(X, y)
    joblib.dump({"pipeline": pipe, "feature_cols": [c for c in cols if c != "y"]}, MODEL_PATH)

if __name__ == "__main__":
    main()
