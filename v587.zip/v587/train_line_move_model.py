# -*- coding: utf-8 -*-
"""
train_line_move_model.py
训练“盘口趋势预测模型”，预测盘口下一段时间是往哪走（steam move）
需要 line_move_dataset.csv
"""

import pandas as pd
import numpy as np
import joblib
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

DATA_PATH = "data/line_move_dataset.csv"
MODEL_PATH = "models/line_move_model.pkl"


def main():

    df = pd.read_csv(DATA_PATH)
    df = df.dropna()

    # 输入特征
    cols = [
        "line",
        "odds_home",
        "odds_away",
        "prob_home_h2h",
        "prob_away_h2h",
        "home_attack_strength",
        "away_attack_strength",
        "home_xg_momentum",
        "away_xg_momentum",
    ]

    X = df[cols].values
    y = df["label"].astype(int).values   # 1=盘口往主队方向走

    pipe = Pipeline([
        ("scaler", StandardScaler()),
        ("gbm", GradientBoostingClassifier(
            n_estimators=200,
            learning_rate=0.05,
            max_depth=3,
            subsample=0.8
        ))
    ])

    pipe.fit(X, y)

    joblib.dump({"pipeline": pipe}, MODEL_PATH)
    print("Saved:", MODEL_PATH)


if __name__ == "__main__":
    main()
