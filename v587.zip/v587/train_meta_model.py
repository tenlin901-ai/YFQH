# -*- coding: utf-8 -*-
"""
train_meta_model.py
训练 meta ensemble 融合模型，提高预测稳定性
需要 meta_dataset.csv
"""

import pandas as pd
import numpy as np
import joblib
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline


DATA_PATH = "data/meta_dataset.csv"
MODEL_PATH = "models/meta_model.pkl"


def main():

    df = pd.read_csv(DATA_PATH)
    df = df.dropna()

    # meta 输入特征（结合 EV、AH预测、盘口深度、xG 强弱等）
    cols = [
        "p_model",
        "ev",
        "move_prob",
        "elo_diff",
        "home_attack_strength",
        "away_attack_strength",
        "home_xg_momentum",
        "away_xg_momentum"
    ]

    X = df[cols].values
    y = df["y"].astype(int).values  # 1=盈利，0=亏损

    pipe = Pipeline([
        ("scaler", StandardScaler()),
        ("gbm", GradientBoostingClassifier(
            n_estimators=300,
            learning_rate=0.05,
            max_depth=3,
            subsample=0.8
        ))
    ])

    pipe.fit(X, y)

    joblib.dump({
        "meta_model": pipe,
        "feature_cols": cols
    }, MODEL_PATH)

    print("Saved:", MODEL_PATH)


if __name__ == "__main__":
    main()
